public class Pista
{
    private boolean pista;
    private double metros;

    public boolean getPista() {
        return pista;
    }

    public void setPista(boolean pista) {
        this.pista = pista;
    }

    public double getMetros() {
        return metros;
    }

    public void setMetros(double metros) {
        this.metros = metros;
    }
}