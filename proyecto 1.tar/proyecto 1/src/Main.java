import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws InterruptedException {

        Thread.sleep(750);
        new Controlador().Opciones(new Valkiria());

    }
}