
echo "---------------------------------------------------------------------------"
echo "---------------------------------------------------------------------------"
echo "                        	W  E  L  C  O  M  E                                      "
echo "                               T   O                                            "
echo "              P I P E L I N E C L I M A T O L O G I C O S                      " 
echo "---------------------------------------------------------------------------"
echo "---------------------------------------------------------------------------"
echo "---------------------------------------------------------------------------"

#Se descargan los archivos CSV 
wget https://srvbioinf1.utalca.cl/~fduran/data.zip 
unzip data.zip
#Se procesa cada archivo para obtener la informacion que sea necesaria y se junta esta en un archivo
ls | grep "Panguilemodetalle20*" >> lista.txt
for info in $(cat lista.txt); #Se desplega el contenido de lista.txt con el comando cat
do 
	echo $info 
	cat $info >> archivo.csv 
	rm $info 
done


sed -i '/Fecha/d' archivo.csv  

#Se genera un nuevo archivo que se analiza linea por linea gracias a awk y que diferencia fecha, temperatura y humedad por ";" 
awk -F ";" '{print $1";"$6";"$7}' archivo.csv > archivo2.csv 

awk '{print $1}' archivo2.csv | awk -F "-" '{print $1"-"$2}' |sort |uniq > añosymes #Se almacenan las fechas en el archivo añoymes

awk '{print $1}' archivo2.csv | awk -F "-" '{print $1}' |sort |uniq > años #Se crea el archivo años


#Se desplega el contenido del archivo años y se analiza en un ciclo
for anio in $(cat años) 
do
	
	rm -r $anio 
	mkdir $anio  #Se creara una carpeta por cada año recorrido en el ciclo
	
	for mes in $(cat añosymes |grep $anio) #Cada año entrara a un ciclo de sus respectivos meses
	do
	
		grep $mes archivo2.csv | awk -F ";" '{print $3}' > temppor_$mes  #Se almacena lo procesado en este archivo, con la variacion del mes correspondiente
		
		#Operacion para calcular la temperatura promedio por cada mes
		TemperaturaProm=$(awk '{ sum += $1; n++ } END { if (n > 0) print sum / n; }' temppor_$mes) 
		 
		#Se pasa la fecha y temperatura promedio al archivo temperatura.csv que varia, segun el año recorrido
		echo   $mes ";" $TemperaturaProm | awk -F "-" '{print $2}' >> $anio/temperatura.csv
		rm -r temppor_$mes #Se elimina la variable usada para obtener los datos mensuales
		
		grep $mes archivo2.csv | awk -F ";" '{print $2}' > humedadpor_$mes #Se almacena lo procesado dependiendo del mes
		
			#Operacion para calcular la humedad promedio por cada mes
		HumedadProm=$(awk '{ sum += $1; n++ } END { if (n > 0) print sum / n; }' humedadpor_$mes) 
		
		#Se pasa la fecha y humedad promedio al archivo humedad.csv que varia, segun el año recorrido
		$mes | awk -F '{print $2}'
		echo   $mes ";" $HumedadProm | awk -F "-" '{print $2}' >> $anio/humedad.csv
		rm -r humedadpor_$mes   
		clear 
	done
	#Se genera un grafico con los promedios de temperatura por cada mes, del año evaluado en el ciclo
	python generateGraphic.py $anio graficoTemperatura $anio/temperatura.csv "Meses" "Grados" "Promedio Temperatura - Año $anio"
	#Se genera un grafico con los promedios de humedad por cada mes, del año evaluado en el ciclo
	python generateGraphic.py $anio graficoHumedad $anio/humedad.csv "Meses" "% Humedad" "Promedio Humedad - Año $anio"
	
done
rm -r archivo.csv archivo2.csv años añosymes lista.txt 08 data.zip  #Se eliminan los archivos utilizados que ya no son necesarios
clear #Se limpia la pantalla una vez todos los datos esten procesados para mostrar el mensaje final
echo "------------------------------------------------------------------------"
echo "-------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------"
echo "			F  I  N  D E L   P R O G R A M A            "
echo "----------------------------------------------------------------------------"
echo "      D A T O S  C L I M A T O L O G I C O S  P R O C E S A D O S "

