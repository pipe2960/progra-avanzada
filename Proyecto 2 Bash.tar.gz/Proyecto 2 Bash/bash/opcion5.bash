#!/bin/bash
cd /home/
find $HOME | grep $1
