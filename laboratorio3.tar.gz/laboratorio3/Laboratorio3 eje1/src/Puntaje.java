public class Puntaje {
}
