
public class Main
{
    public static void main(String[] args)
    {
        Pregunta p=new Pregunta();
        p.cantidadpregunta();
        p.ingresarpregunta();


    }
}
