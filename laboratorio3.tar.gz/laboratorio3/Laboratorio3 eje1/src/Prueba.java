import java.util.ArrayList;

public class Prueba {
 private String[] preguntas = new String[500];

 public Pregunta preguntaprueba = new Pregunta();
Prueba()
{

}

 Prueba(String[] preguntas){
   this.preguntas = preguntas;
 }

 public void generarprueba(String pruebanueva)
 {
System.out.println("La prueba es : " + pruebanueva +"[20 PTS]");



  }

  }


