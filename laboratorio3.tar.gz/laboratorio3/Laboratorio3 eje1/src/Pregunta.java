import java.util.Scanner;

public class Pregunta
{
    private String[] p = new String[500];
    private String[] prueba = new String[500];
    public Prueba prue;
    private int puntaje;
    int cantidad;
    String  pregunta ;
    int i;



    private Scanner sc = new Scanner(System.in);



    public int getPuntaje()
    {
        return puntaje;
    }


    public String[] getP() {
        return p;
    }

    public void setP(String[] p) {
        this.p = p;
    }

    public void setPuntaje(int puntaje)
    {


        this.puntaje = puntaje;
    }

    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    public int  cantidadpregunta ()
    {

        System.out.println("Ingrese la cantidad de preguntas");
        cantidad=sc.nextInt();
        sc.nextLine();
        return cantidad;

    }

    int azar =(int)(Math.random()*cantidad)+1;




    public void ingresarpregunta() {
        prue = new Prueba();
        for ( i = 0; i< cantidad; i++) {
            System.out.println("Ingrese la pregunta: " + (i+1));
             pregunta= sc.nextLine();
             p[i]=pregunta;


        }

        for(int j=0; j<5;j++)
        {
            int azar =(int)(Math.random()*cantidad)+1;



            prueba[j]=p[azar];

            prue.generarprueba(prueba[j]);

        }




    }






}
