public class Hertz {
}
