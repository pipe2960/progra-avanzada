import java.util.ArrayList;

public class Marca
{
    private ArrayList<String> modelos =new ArrayList<String> ();


}
